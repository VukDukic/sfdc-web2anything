<?php

//change the value of $DebugOn to 0 (zero) to disable debugging
$DebugOn = 1;

//don't edit what's underneath here unless you know what you're doing
error_reporting(0);
require_once('./php_sforce_nusoap/salesforce.php');
require_once('../config.inc.php');

if (isset($_POST[ 'sObj' ])) {
    create_record();
} else {
    echo 'Error! sObj not found in POST message.';
}

function create_record() {
    
    global $DebugOn;
    $FieldList = array();
    
    foreach($_POST as $field => $value) {
        
        if ($field == 'sObj') {
            $sObjectName = $value;
        } else if ($field == 'retURL') {
            $retURL = $value;
        } else if ($field == 'submit') {
            #null
        } else if ($value == '') {
            #null
        } else {
            #split the "type_field"
            $typesplit = strpos($field, '_');
            $fieldtype = substr($field, 0, $typesplit);
            $field = substr($field, $typesplit + 1);
            //"date" and "dateTime" need to be set as xs:date or xs:dateTime - http://www.w3schools.com/Schema/schema_dtypes_date.asp
            if ($fieldtype == 'date' || $fieldtype == 'datetime') {
                //todo: give option to select date input format
                $field = new soapval($field, 'date', $value);
                $FieldList[ '' ] = $field;
                //checkboxes are posted as "on", "off" and need to be changed to TRUE, FALSE
            } else if ($fieldtype == 'checkbox') {
                $value == 'on' ? $value = TRUE : $value = FALSE;
                $FieldList[ $field ] = $value;
            } else {
                //just adds the fields and values in the array
                $FieldList[ $field ] = $value;
            }
        }
    }
    
    if ($DebugOn == 1) {
        echo 'Array of fields/values collected from the submitted form:';
        print_array($FieldList);
        write_record($FieldList, $sObjectName, $retURL);
    } else {
        write_record($FieldList, $sObjectName, $retURL);
    }
}

function write_record($fieldsArray, $sObj, $retURL) {
    
    global $DebugOn;
    global $username;
    global $password;
    global $security_token;
    
    $password = $password . $security_token;
    $wsdl = './php_sforce_nusoap/partner.wsdl';
    $mySforceConnection = new salesforce($wsdl);
    $mylogin = $mySforceConnection -> login($username, $password);
    
    if (!$mylogin) {
        echo 'ERROR connecting, check username/password.';
        print_array($mySforceConnection -> result);
    } else {
        $sObject = new SObject($sObj, null, $fieldsArray);
        $create_record = $mySforceConnection -> create($sObject);
        
        if ($create_record[ 'success' ] == 'true') { //if record is created successfully
        
          if (( !empty($_FILES[ 'upload_file' ])) && ( $_FILES[ 'upload_file' ][ 'error' ] == 0)) { //process the attachment (if one)
          
            if ($_FILES[ 'upload_file' ][ 'size' ] > 5242880) { //file too big
            
                echo 'Your entry has been successfully recorded but the attached file was bigger than 5MB and has not been saved.'; 
            
            } else { //save file locally, then insert to salesforce
            
                $savetodir = '../uploads/';
                $target = $savetodir . basename($_FILES[ 'upload_file' ][ 'name' ]);
                move_uploaded_file($_FILES[ 'upload_file' ][ 'tmp_name' ], $target) or die("ERROR saving attachment, make sure the uploads/ directory is writable.");;
                $handle = fopen($target, 'rb') or die("ERROR opening attachment, make sure the uploads/ directory is readable.");
                $file_content = fread($handle, filesize($target));
                fclose($handle);
                $encoded = base64_encode($file_content);
                $attach = new sObject('Attachment', null, array('Name' => $_FILES[ 'upload_file' ][ 'name' ], 'ParentId' => $create_record[ 'id' ], new soapval('Body', 'base64Binary', $encoded)));
                $create_attachment = $mySforceConnection -> create($attach);
                
                if ($create_attachment[ 'success' ] == 'true') { //if attachment is created in SFDC
                
                  if ($DebugOn == 1) {  
                      echo "SFDC Record ID $create_record[id] created successfully!";
                      print_array($create_record);
                      echo "SFDC Attachment ID $create_attachment[id] created successfully!";
                      print_array($create_attachment);
                  } else { header("Location: $retURL"); }
                
                } else { //couldn't create the attachment
                
                    if ($DebugOn == 1) {
                        echo "SFDC Record ID $create_record[id] created successfully";
                        print_array($create_record);
                        echo "ERROR uploading attachment to SFDC, file only saved locally.";
                    } else { 
                        header("Location: $retURL"); 
                        //todo: log an activity to inform record owner the file is only saved on webserver
                    }
                }
            }
          } else { //no attachment, confirm only record creation
          
            if ($DebugOn == 1) {
                echo "SFDC Record ID $create_record[id] created successfully!";
                print_array($create_record);
            } else { header("Location: $retURL"); }
          }
        } else { //create call not successfull, throw error
            echo 'ERROR creating the record!';
            print_array($create_record);
        }
    }
}

function print_array($array) {
    print('<pre>');
    print_r($array);
    print('</pre>');
}
?>
<?php

//using salesforce nusoap
//http://sourceforge.net/project/showfiles.php?group_id=96634&package_id=166314
require_once('./php_sforce_nusoap/salesforce.php');

//credentials
require_once('../config.inc.php');

if (isset ($_POST['sObj'])) {
  create_record();
} else {
  echo "Error! sObj not found in POST message.";
}
 
function create_record() {

  $DebugOn = 0;
  $FieldList = array();

  foreach ($_POST as $field=>$value) {
  
    if ($field == "sObj") {
      $sObjectName = $value;
    }	else if ($field == "retURL") {
      $retURL = $value;
    }	else if ($field == "submit") {
      //null
    }	else if ($value == "") {
      //null
    }	else {
    
      //split the "type_field"
      $typesplit = strpos($field, "_");
      $fieldtype = substr($field, 0, $typesplit);
      $field = substr($field, $typesplit + 1);
      
      //types "date" and "dateTime" need to be set as xs:date or xs:dateTime
      //http://www.w3schools.com/Schema/schema_dtypes_date.asp
      if ($fieldtype == "date" || $fieldtype == "datetime") {
      
        //i should check if $field here is in form of YYYY-MM-DD or
        //maybe give option to select date input form
        $field = new soapval($field,'date',$value);
        $FieldList[] = $field;
        
      //checkboxes are posted as "1", "0" and need to be changed to TRUE, FALSE
      } else if ($fieldtype == "checkbox") {
      
        $value == "1" ? $value = "FALSE" : $value = "TRUE";
        $FieldList[$field] = $value;
        
      } else {
      
        //just adds the fields and values in the array
  			$FieldList[$field] = $value;
  			
  	  }
    }
  }
	
	if($DebugOn == 1) {
    echo "Debug on:";
    print_array($FieldList);
	} else {
    write_record($FieldList,$sObjectName,$retURL);
  }
  
}

function print_array($array) {

  print("<pre>");
  print_r($array);
  print("</pre>");
    
}

function write_record($fieldsArray,$sObj,$retURL) {

  try {
	
	  global $username;
	  global $password;
	  global $security_token;
	  //setting the password to be password + security token
	  $password = $password . $security_token;
	  
	  $wsdl = './php_sforce_nusoap/partner.wsdl';
	  
	  $mySforceConnection = new salesforce($wsdl);
	  $mylogin = $mySforceConnection->login($username, $password);
	  
	  if (!$mylogin) {

      echo "Error!";
      print_array($mySforceConnection->result);

    } else {

      $sObject = new SObject($sObj,null,$fieldsArray);
  
      $createResponse = $mySforceConnection->create($sObject);
    
      if($createResponse[success] == "true") {
        //echo "Record ID $createResponse[id] created successfully!";
        //print_array($mySforceConnection->result);
        header("Location: $retURL");
      } else {
        echo "Error!";
        print_array($createResponse);
      }
    
    }

  } catch (Exception $e) {
    echo "Error!<br><br>";
    echo $mySforceConnection->getLastRequest();
    echo $e->faultstring;
  }

}

?>
<?php

#using salesforce nusoap - http://sourceforge.net/project/showfiles.php?group_id=96634&package_id=166314
require_once('./php_sforce_nusoap/salesforce.php');

#credentials
require_once('../config.inc.php');

#0 = off, 1 = on
$DebugOn = 1;

if (isset($_POST[ 'sObj' ])) {
    create_record();
} else {
    echo 'Error! sObj not found in POST message.';
}

function create_record() {
    
    global $DebugOn;
    $FieldList = array();
    
    foreach($_POST as $field => $value) {
        
        if ($field == 'sObj') {
            $sObjectName = $value;
        } else if ($field == 'retURL') {
            $retURL = $value;
        } else if ($field == 'submit') {
            #null
        } else if ($value == '') {
            #null
        } else {
            #split the "type_field"
            $typesplit = strpos($field, '_');
            $fieldtype = substr($field, 0, $typesplit);
            $field = substr($field, $typesplit + 1);
            #"date" and "dateTime" need to be set as xs:date or xs:dateTime - http://www.w3schools.com/Schema/schema_dtypes_date.asp
            if ($fieldtype == 'date' || $fieldtype == 'datetime') {
                #todo: give option to select date input format
                $field = new soapval($field, 'date', $value);
                $FieldList[ '' ] = $field;
                #checkboxes are posted as "on", "off" and need to be changed to TRUE, FALSE
            } else if ($fieldtype == 'checkbox') {
                $value == 'on' ? $value = TRUE : $value = FALSE;
                $FieldList[ $field ] = $value;
            } else {
                #just adds the fields and values in the array
                $FieldList[ $field ] = $value;
            }
        }
    }
    
    if ($DebugOn == 1) {
        echo 'Array of fields/values posted:';
        print_array($FieldList);
        write_record($FieldList, $sObjectName, $retURL);
    } else {
        write_record($FieldList, $sObjectName, $retURL);
    }
}

function write_record($fieldsArray, $sObj, $retURL) {
    
    global $DebugOn;
    global $username;
    global $password;
    global $security_token;
    
    #setting the password to be password + security token
    $password = $password . $security_token;
    $wsdl = './php_sforce_nusoap/partner.wsdl';
    $mySforceConnection = new salesforce($wsdl);
    $mylogin = $mySforceConnection -> login($username, $password);
    
    if (!$mylogin) {
        echo 'ERROR connecting, check username/password.';
        print_array($mySforceConnection -> result);
    } else {
        $sObject = new SObject($sObj, null, $fieldsArray);
        $create_record = $mySforceConnection -> create($sObject);
        
        if ($create_record[ 'success' ] == 'true') {
            
            #process the attachment (if one)
            if (( !empty($_FILES[ 'upload_file' ])) && ( $_FILES[ 'upload_file' ][ 'error' ] == 0)) {
            
              if ($_FILES[ 'upload_file' ][ 'size' ] > 5242880) {
                  echo 'Your entry has been successfully recorded, but unfortunately the file chosen was bigger than 5MB and has not been saved.'; 
              
              } else {
                  $target = 'upload/';
                  $target = $target . basename($_FILES[ 'upload_file' ][ 'name' ]);
                  
                  if (move_uploaded_file($_FILES[ 'upload_file' ][ 'tmp_name' ], $target)) {
                
                      $source_file = 'upload/' . $_FILES[ 'upload_file' ][ 'name' ];
                      $handle = fopen($source_file, 'rb');
                      $file_content = fread($handle, filesize($source_file));
                      fclose($handle);
                      $encoded = base64_encode($file_content);
                      $attach = new sObject('Attachment', null, array('Name' => $_FILES[ 'upload_file' ][ 'name' ], 'ParentId' => $create_record[ 'id' ], new soapval('Body', 'base64Binary', $encoded)));
                      $create_attachment = $mySforceConnection -> create($attach);
                      
                      if ($DebugOn == 1) {
                          echo "Record ID $create_record[id] created successfully!";
                          print_array($create_record);
                          echo "Attachment ID $create_attachment[id] created successfully!";
                          print_array($create_attachment);
                      } else { header("Location: $retURL"); }
                  
                  #record created, file saved only locally
                  } else {
                      if ($DebugOn == 1) {
                          echo "Record ID $create_record[id] created successfully";
                          print_array($create_record);
                          echo "ERROR uploading attachment to Salesforce, file only saved locally.";
                      } else { 
                          header("Location: $retURL"); 
                          #TODO: add an activity to the record to inform record owner the file is saved only locally
                      }
                  }
              }
          
          #if no attachment confirm only record creation  
          } else {
              if ($DebugOn == 1) {
                  echo "Record ID $create_record[id] created successfully!";
                  print_array($create_record);
              } else { header("Location: $retURL"); }
          }
        
        #if create call not successfull throw error
        } else {
            echo 'ERROR creating the record!';
            print_array($create_record);
        }
    }
}

function print_array($array) {
    print('<pre>');
    print_r($array);
    print('</pre>');
}
?>